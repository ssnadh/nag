uninstallODIBinaries
====================

A brief description of the role goes here.

Requirements
------------

Any pre-requisites that may not be covered by Ansible itself or the role should be mentioned here. For instance, if the role uses the EC2 module, it may be a good idea to mention in this section that the boto package is required.

Role Variables
--------------

The role requires the following variables set:

* ORACLE_HOME (FQP to binary installation)

If not provided, they default to OI domain setup standards:

ORACLE_HOME: /opt/oracle/FMW12.2

It uses two other variables to create the response files for teh uninstaller:

* odi_response_file_path: "/tmp/uninstallOdi122130.rsp"
* fmw_response_file_path: "/tmp/uninstallFmw122130.rsp"

Those will be automatically removed after an uninstallation.

Dependencies
------------

No dependencies.

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - uninstallODIBinaries

License
-------

For internal use only.

Author Information
------------------

kai.fricke@ingka.com